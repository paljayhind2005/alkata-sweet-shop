import StoreRouter, { routes } from './store-router';

export { routes };

export default StoreRouter;
